<?php
namespace IWD\Opc\Block;

class Onepage extends \Magento\Checkout\Block\Onepage
{

}